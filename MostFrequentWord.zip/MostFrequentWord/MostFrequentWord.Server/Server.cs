﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MostFrequentWord.Server
{
    public class Server : IDisposable
    {
        private readonly CancellationTokenSource _cancellationTokenSource = new CancellationTokenSource();
        private readonly HttpListener            _httpListener            = new HttpListener();

        public Task StartListening(IPEndPoint endPoint)
        {
            if (_httpListener.IsListening)
                throw new InvalidOperationException("Server is already listening");

            return Task.Run(async () =>
            {
                _httpListener.Prefixes.Add($"http://{endPoint.Address}:{endPoint.Port}/");

                _httpListener.Start();

                while (!_cancellationTokenSource.IsCancellationRequested)
                {
                    var context = await _httpListener.GetContextAsync();

                    using (var ms = new MemoryStream())
                    {
                        await context.Request.InputStream.CopyToAsync(ms);
                        string message = Encoding.UTF8.GetString(ms.ToArray());
                        var    result  = MostFrequentWordsInfo.GetMostFrequentWord(message);

                        Console.WriteLine($"Received message \"{message}\", sending response \"{result}\"");

                        var resultBytes = Encoding.UTF8.GetBytes(result.ToString());
                        await context.Response.OutputStream.WriteAsync(resultBytes, 0, resultBytes.Length);
                        context.Response.OutputStream.Close();
                    }
                }
            });
        }

        public void Dispose()
        {
            _cancellationTokenSource?.Dispose();
            _httpListener?.Close();
        }
    }
}