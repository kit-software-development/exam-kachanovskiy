﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MostFrequentWord.Server
{
    public class MostFrequentWordsInfo
    {
        public MostFrequentWordsInfo(String[] words, Int32 count)
        {
            Words = words;
            Count = count;
        }

        public String[] Words { get; }
        public int      Count { get; }

        public static MostFrequentWordsInfo GetMostFrequentWord(String str)
        {
            var words = str.Split(' ');
            var groups = words
                .GroupBy(word => word)
                .OrderByDescending(group => group.Count());

            int maxCount = groups.Max(grp => grp.Count());
            var mostFrequentWords = groups.Where(group => group.Count() == maxCount)
                .Select(grp => grp.Key)
                .ToArray();

            return new MostFrequentWordsInfo(mostFrequentWords, maxCount);
        }

        public override String ToString()
        {
            var wordsString = String.Join(",", Words);
            return $"{wordsString}:{Count}";
        }
    }
}