﻿using System.Net;

namespace MostFrequentWord.Server
{
    internal static class Program
    {
        public static void Main(string[] args)
        {
            using (var server = new Server())
            {
                server.StartListening(new IPEndPoint(IPAddress.Loopback, 22)).Wait();
            }
        }
    }
}