﻿using System;
using System.Net;
using System.Net.Http;

namespace MostFrequentWord.Client
{
    internal static class Program
    {
        public static void Main(string[] args)
        {
            var endpoint   = new IPEndPoint(IPAddress.Loopback, 22);
            var httpCLient = new HttpClient();

            while (true)
            {
                Console.WriteLine("Type message...");
                string message = Console.ReadLine();

                string uri = $"http://{endpoint.Address}:{endpoint.Port}/";

                var request = new HttpRequestMessage(HttpMethod.Post, uri);
                request.Content = new StringContent(message);

                var response        = httpCLient.SendAsync(request).Result;
                var responseMessage = response.Content.ReadAsStringAsync().Result;
                Console.WriteLine($"Received message \"{responseMessage}\"");
            }
        }
    }
}